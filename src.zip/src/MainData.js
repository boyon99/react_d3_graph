export const MAIN_DATA = [
  {
    id: 1,
    text: "코로나 전",
    name: "covidBefore",
  },
  {
    id: 2,
    text: "코로나 후",
    name: "covidAfter",
  },
];
