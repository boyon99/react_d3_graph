import React from "react";
import { D3BarGraph } from "./BarGraph";

export default function SeoulStayBefore() {
  return (
    <div>
      <D3BarGraph />
    </div>
  );
}