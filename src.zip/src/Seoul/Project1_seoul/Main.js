import React from "react";
import { D3BarGraph } from "./BarGraph";

export default function SeoulStayAfter() {
  return (
    <div>
      <D3BarGraph />
    </div>
  );
}