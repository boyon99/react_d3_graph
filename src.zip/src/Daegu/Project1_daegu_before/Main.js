import React from "react";
import { DaeguBarBefore } from "./BarGraph";

export default function App() {
  return (
    <div>
      <DaeguBarBefore />
    </div>
  );
}