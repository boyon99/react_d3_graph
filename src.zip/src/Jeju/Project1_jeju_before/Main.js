import React from "react";
import { JejuBarBefore } from "./BarGraph";

export default function JejuStayBefore() {
  return (
    <div>
      <JejuBarBefore />
    </div>
  );
}