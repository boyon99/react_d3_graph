import React from "react";
import { JejuBarAfter } from "./BarGraph";


export default function JejuStayAfter(){
  return (
    <div>
      <JejuBarAfter />
    </div>
  );
}