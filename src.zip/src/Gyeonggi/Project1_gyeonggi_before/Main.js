import React from "react";
import { GyeongiBarBefore } from "./BarGraph";

export default function BarGyeongiBefore() {
  return (
    <div>
      <GyeongiBarBefore />
    </div>
  );
}