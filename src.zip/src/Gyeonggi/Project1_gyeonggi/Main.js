import React from "react";
import { GyeongiBarAfter } from "./BarGraph";

export default function BarGyeongiAfter(){
  return (
    <div>
      <GyeongiBarAfter />
    </div>
  );
}