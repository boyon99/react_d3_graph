import React from "react";
import { GangWonBarBefore } from "./BarGraph";

export default function BarGangwonBefore(){
  return (
    <div>
      <GangWonBarBefore />
    </div>
  );
}