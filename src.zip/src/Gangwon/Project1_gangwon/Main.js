import React from "react";
import { GangWonBarAfter } from "./BarGraph";

export default function BarGangwonAfter() {
  return (
    <div>
      <GangWonBarAfter />
    </div>
  );
}