import React from "react";
import { IncheonBarBefore } from "./BarGraph";

export default function BarIncheonBefore() {
  return (
    <div>
      <IncheonBarBefore />
    </div>
  );
}