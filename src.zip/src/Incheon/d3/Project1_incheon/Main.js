import React from "react";
import { IncheonBarAfter } from "./BarGraph";

export default function BarIncheonAfter(){
  return (
    <div>
      <IncheonBarAfter />
    </div>
  );
}