import KoreaMap from "./KoreaMap";
import AppRouter from "./Router";

function App() {
  return (
  <AppRouter />

  );
}

export default App;
