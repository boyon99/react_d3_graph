import React from "react";
import { AllBarBefore } from "./BarGraph";

export default function App() {
  return (
    <div>
      <AllBarBefore />
    </div>
  );
}