import React from "react";
import { BusanBarBefore } from "./BarGraph";

export default function BarBusanBefore() {
  return (
    <div>
      <BusanBarBefore />
    </div>
  );
}