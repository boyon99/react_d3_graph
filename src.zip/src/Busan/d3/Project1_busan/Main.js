import React from "react";
import { BusanBarAfter } from "./BarGraph";

export default function BarBusanAfter() {
  return (
    <div>
    <BusanBarAfter />
  </div>
  );
}